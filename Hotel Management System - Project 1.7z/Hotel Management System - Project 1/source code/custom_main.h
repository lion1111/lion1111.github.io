#ifndef CUSTOM_MAIN_H
#define CUSTOM_MAIN_H

int custom_main();

#endif /* CUSTOM_MAIN_H */