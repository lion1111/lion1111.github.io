#include "custom_main.h"

using namespace std;

/*This function does not have a header file, and so it is used to call another 
 * function(custom_main), reasons are explained in the function. 
 */
int main() {
    custom_main();
    return 0;
}